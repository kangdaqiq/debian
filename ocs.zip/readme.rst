###################
APA WEBSSH?
###################

Webssh Adalah sebuah webscript host simple untuk para penjual ssh atau untuk web public
ssh Komersial.
Webssh dibangun menggunakan framwork codeignither 3.1.7
https://www.codeigniter.com/

*******************
Informasi Rilis
*******************

Repo ini mengandung pengembangan developer untuk menambah fitur ataupun bug
Untuk download versi stable` Downloads
<https://webssh.xyz/download>`_ page.

**************************
Changelog and New Features
**************************

Kamu juga Bisa mengecek rilis baru ataupun lama di `user
guide change log <https://github.com/adipatiarya/webssh.git>`_.

*******************
Server Requirements
*******************

PHP versi 5.6 atau diatasnya disarankan.

It should work on 5.3.7 as well, but we strongly advise you NOT to run
such old versions of PHP, because of potential security and performance
issues, as well as missing features.

************
Installation
************

*******************
Domain Requirements
*******************

Domain harus support HTTPS
script ini di desain untuk domain yg support https(auto redirect https only).


Lihat di `sesi install <https://webssh.xyz/user_guide/installation/index.html>`_
Untuk panduan pengisntalan webssh.

*******
License
*******

Lihat juga `license
agreement <https://github.com/adipatiarya/webssh/blob/develop/user_guide_src/source/license.rst>`_.

*********
Resources
*********

-  `Panduan <https://webssh.xyz/docs>`_
-  `Language File Translations <https://github.com/bcit-ci/codeigniter3-translations>`_
-  `Community Forums <http://forum.codeigniter.com/>`_
-  `Community Wiki <https://github.com/bcit-ci/CodeIgniter/wiki>`_
-  `Community Slack Channel <https://codeigniterchat.slack.com>`_

Laporkan bug `Security Panel <mailto:aryaadipati2@gmail.com>`_
or via our `page on HackerOne <https://hackerone.com/webssh>`_, Trima kasih.

***************
Moral Donation
***************

Donasi seiklasnya untuk membantu developer  meningkatkan layanan atau memperbaiki bug.
Donasi bisa dikirim via rek

BCA 842 031 3561 (SURATMAN)
PAYPAL aryaadipati2@gmail.com