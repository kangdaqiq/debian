<?php
/**
 * Name:    Ar Panel
 * Author:  Adipati Arya
 *           jawircodes@gmail.com
 *           @benedmunds
 *
 * Added Awesomeness: Adipati Arya
 *
 * Created:  10.01.2009
 *
 * Description:  Panel SSH modul manajemen users.
 *
 * Requirements: PHP5 or above
 *
 * @package    CodeIgniter-Ar-panel
 * @author     Adipati arya
 * 
 * 
 */
defined('BASEPATH') OR exit('No direct script access allowed');

$config['version'] = "1.0";
$config['template'] = 'default';

